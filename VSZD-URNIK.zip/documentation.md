<!-- install python3 -->

<!-- in cmd or linux shell copy and run  -->
pip install -r requirements.txt
python3 vszd.py